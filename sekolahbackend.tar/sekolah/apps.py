from django.apps import AppConfig


class SekolahConfig(AppConfig):
    name = 'sekolah'
